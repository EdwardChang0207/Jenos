x = 10
y = '5.1'
z = True
print(type(x))
print(type(y))
print(type(z))
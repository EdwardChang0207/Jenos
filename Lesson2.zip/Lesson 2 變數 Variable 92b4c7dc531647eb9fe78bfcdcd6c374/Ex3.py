x = 10
print(x+10)
x = 'hello'
print(x)
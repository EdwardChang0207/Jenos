x = 10
y = '5.1'
z = True
print(x)
print(y)
print(z)